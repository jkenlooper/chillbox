select datetime('now') as thetime;
