from os import getenv

SERVER_NAME = getenv("SERVER_NAME")
HOST = getenv("HOST")
PORT = int(getenv("PORT"))
