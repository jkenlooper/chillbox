# Breakfast Menu for 

- Spam
- Eggs